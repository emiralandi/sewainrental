// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://sewain-aplikasi-rental-bmwq9j.zedeai2026.workers.dev";
