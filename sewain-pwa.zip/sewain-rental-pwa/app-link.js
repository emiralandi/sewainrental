// Link /exec aplikasimu dari Apps Script (Terapkan → Kelola deployment).
window.APP_LINK = "https://sewain-rental-bmwrt8.zedeai2026.workers.dev";
